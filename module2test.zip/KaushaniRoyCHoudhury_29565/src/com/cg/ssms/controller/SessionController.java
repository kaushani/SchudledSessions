package com.cg.ssms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ssms.bean.ScheduleSessions;
import com.cg.ssms.exception.SessionException;
import com.cg.ssms.service.ISessionService;
//controller of the program
@Controller
public class SessionController {

	@Autowired
	ISessionService obService;
	@RequestMapping("/showScheduledSessions")
	public String showScheduledSessions()
	{
		return "ScheduledSessions";
		
	}
	@RequestMapping("/printScheduledSessions")
	public ModelAndView printScheduledSessions() throws SessionException {

		ModelAndView mv = new ModelAndView();

		List<ScheduleSessions> list = null;
		System.out.println("HELLLLLLLOOOOOO");

			list = obService.printAllSessions();
			System.out.println(list);
			mv.setViewName("ScheduledSessions");
			// Add the attribute to the model
			mv.addObject("list", list);
	
		return mv;
	}
	@RequestMapping("/Enroll")
	public ModelAndView searchTrainee(@RequestParam("sessionName") String sessionName) throws SessionException {
		ModelAndView mv = null;
		//ScheduleSessions session = obService.searchSession(sessionName);
		if (sessionName != null) {
			mv = new ModelAndView("Success", "sessionName", sessionName);
		} 

		return mv;
	}
}

package com.cg.ssms.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ssms.exception.SessionException;
//class handling exceptions
@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(value = {SessionException.class})
    protected ModelAndView handleConflict(Exception ex) {
		ModelAndView model = new ModelAndView("error");
		model.addObject("errMsg", ex.getMessage());
		return model;
    }
}

package com.cg.ssms.exception;
//custom made exception class
public class SessionException extends Exception
{

	public SessionException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	

}

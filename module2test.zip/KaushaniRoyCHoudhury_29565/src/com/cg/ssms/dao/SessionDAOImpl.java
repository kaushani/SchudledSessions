package com.cg.ssms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.ssms.bean.ScheduleSessions;
import com.cg.ssms.exception.SessionException;
@Repository

public class SessionDAOImpl implements ISessionDAO{

	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public List<ScheduleSessions> printAllSessions() throws SessionException {
		// TODO Auto-generated method stub
		try
		{
			System.out.println("In DAOOOOOOOOOO");
		TypedQuery<ScheduleSessions> query = entityManager.createQuery("SELECT session FROM ScheduleSessions session", ScheduleSessions.class);
		System.out.println(query.getResultList());
		return query.getResultList();
		
		}
		catch(Exception e)
		{
			throw new SessionException("Error in Dao"+ e.getMessage());
		}
	}
	@Override
	public ScheduleSessions searchSession(String sessionName) throws SessionException {
		// TODO Auto-generated method stub
		ScheduleSessions session;
		try {
			session = entityManager.find(ScheduleSessions.class, sessionName);
		} catch (Exception e) {
			throw new SessionException("Exception found in Search session nethod . ."+ e.getMessage());
		}
		
		return session;
	}

}

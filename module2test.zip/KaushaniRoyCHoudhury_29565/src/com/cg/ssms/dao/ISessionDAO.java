package com.cg.ssms.dao;

import java.util.List;

import com.cg.ssms.bean.ScheduleSessions;
import com.cg.ssms.exception.SessionException;
//interface of dao
public interface ISessionDAO {

	List<ScheduleSessions> printAllSessions() throws SessionException;//to print all records
	ScheduleSessions searchSession(String sessionName) throws SessionException;//search a record by session name
}

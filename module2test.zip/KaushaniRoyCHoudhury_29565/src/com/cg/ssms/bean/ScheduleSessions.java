package com.cg.ssms.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
//beanclass
@Entity
@Table(name="scheduledsessions")
public class ScheduleSessions {
	@Id
	private int id;
private String sessionName;
private int duration;
private String faculty;
private String model;
//gettersetters
public String getSessionName() {
	return sessionName;
}
public void setSessionName(String sessionName) {
	this.sessionName = sessionName;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
public String getFaculty() {
	return faculty;
}
public void setFaculty(String faculty) {
	this.faculty = faculty;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
//tostring
@Override
public String toString() {
	return "ScheduleSessions [id=" + id + ", sessionName=" + sessionName + ", duration=" + duration + ", faculty="
			+ faculty + ", model=" + model + "]";
}

}

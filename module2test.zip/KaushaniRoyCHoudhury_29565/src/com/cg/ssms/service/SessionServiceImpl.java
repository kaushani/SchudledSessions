package com.cg.ssms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ssms.bean.ScheduleSessions;
import com.cg.ssms.dao.ISessionDAO;
import com.cg.ssms.exception.SessionException;
// implementation of service interface
@Service
@Transactional
public class SessionServiceImpl implements ISessionService{

	@Autowired
	ISessionDAO obDao;
	@Override
	public List<ScheduleSessions> printAllSessions() throws SessionException {
		return obDao.printAllSessions();
	}
	@Override
	public ScheduleSessions searchSession(String sessionName) throws SessionException {
		// TODO Auto-generated method stub
		return obDao.searchSession(sessionName);
	}

	
}

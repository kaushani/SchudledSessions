package com.cg.ssms.service;

import java.util.List;

import com.cg.ssms.bean.ScheduleSessions;
import com.cg.ssms.exception.SessionException;
// interface of service
public interface ISessionService {

	List<ScheduleSessions> printAllSessions() throws SessionException;
	ScheduleSessions searchSession(String sessionName) throws SessionException;

}
